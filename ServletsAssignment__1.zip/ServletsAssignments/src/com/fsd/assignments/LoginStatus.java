package com.fsd.assignments;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/status")
public class LoginStatus extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		PrintWriter out = response.getWriter();
		String name="admin";
		String pass="password";
		
		String reqname = request.getParameter("uname");
		String reqpass = request.getParameter("upass");
		
		if(reqname.equals(name) && (reqpass.equals(pass)))
		{
			RequestDispatcher dispatch = request.getRequestDispatcher("success.html");
		
			dispatch.forward(request, response);
			
		}
		
		else if((reqname == null) || (reqpass == null))
		{
			out.println("Invalid Username or Password");
			
			RequestDispatcher disp = request.getRequestDispatcher("index1.html");
			
			disp.forward(request, response);
		}
		
		else
		{
			RequestDispatcher disp = request.getRequestDispatcher("failure.html");
			
			disp.forward(request, response);
		}
	}

}
