package com.ibm.takehome.bean;

public class Product {

	int ProdCode , Price ;
	String ProdName ,  ProdCategory ;
	Product prod;
	public Product(int ProdCode , String ProdName , String ProdCategory , int Price){
		this.ProdCode = ProdCode ;
		this.ProdName = ProdName;
		this.ProdCategory=ProdCategory ; 
		this.Price = Price;
	}

	
	public Integer getProdCode()
	{
		return this.ProdCode;
	}
	
	public Integer getPrice()
	{
		return this.Price;
	}
	
	public String getProdName()
	{
		return this.ProdName;
	}
	
	public String getProdCategory()
	{
		return this.ProdCategory;
	}
	
	@Override
	public String toString()
	{
		return ("Product Code:"+this.getProdCode() +"\tProduct Name:" +this.getProdName() + "\tProduct Category:" +this.getProdCategory() + "\tProduct Price;" +this.getPrice());
	}

	
	
}
