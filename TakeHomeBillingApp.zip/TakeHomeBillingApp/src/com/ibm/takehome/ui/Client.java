package com.ibm.takehome.ui;

import java.util.Scanner;

import com.ibm.takehome.service.ProductService;

public class Client {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Product Code:");
		int ProdCode = sc.nextInt();
		sc.nextLine();
		
		
//		System.out.println("Enter Product Name:");
//		String Name = sc.nextLine();
//		System.out.println("Enter Product Category");
//		String Category = sc.nextLine();
//		System.out.println("Enter Price of the Product:");
//		int Price = sc.nextInt();
		System.out.println("Enter Quantity:");
		int quantity = sc.nextInt();
		sc.nextLine();
		
		
//
//		new Product(ProdCode , Name , Category , Price);
		ProductService prod = new ProductService();
		 
		 prod.getProductDetails(ProdCode , quantity);
		
		
		

	}

}
