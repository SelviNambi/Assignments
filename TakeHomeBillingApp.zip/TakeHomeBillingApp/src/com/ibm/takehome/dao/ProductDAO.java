package com.ibm.takehome.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.ibm.takehome.bean.Product;

public class ProductDAO implements IProductDAO{

	 Map<Integer , Product> products = new HashMap<Integer , Product>();
	

	 


public void getProductDetails(int ProdCode , int count )
{
	Set<Integer> keySet = products.keySet();
	Iterator<Integer> keySetIterator = keySet.iterator();
	while (keySetIterator.hasNext()) {
	   System.out.println("------------------------------------------------");
	   
	   Integer key = keySetIterator.next();
	   if(ProdCode == key)
	   {
		   System.out.println("key: " + key + "  " + products.get(key));
		  int Total = products.get(key).getPrice() * count;
		  System.out.println("Total Price " +Total);
		  break;
	   }
	}
}





}
