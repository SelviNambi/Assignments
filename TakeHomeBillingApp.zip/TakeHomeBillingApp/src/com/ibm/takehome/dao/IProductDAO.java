package com.ibm.takehome.dao;

public interface IProductDAO {
	
	void getProductDetails(int ProdCode , int count);
}
