package com.ibm.takehome.service;

import com.ibm.takehome.dao.ProductDAO;

public class ProductService implements IProductService{
	
	public void getProductDetails(int ProdCode, int quantity)
	{
		new ProductDAO().getProductDetails(ProdCode , quantity);
		
		
	}
}
