package com.ibm.takehome.service;

public interface IProductService {

	void getProductDetails(int ProdCode , int count);
}
